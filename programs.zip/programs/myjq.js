(function($){
$.fn.makeChange=function(){
this.css({color:"red",fontStyle:"Italic",fontSize:50});
return this;
 };
}(jQuery));   